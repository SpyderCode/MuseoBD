package BaseDatos.Altas;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import BaseDatos.Conexion;
import BaseDatos.MuseoBD;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class AltaEstatua extends JInternalFrame{
	public MuseoBD principal;
	public JPanel contentPanel;
	private JTextField txtIdObje;
	private JTextField txtMaterial;

	public AltaEstatua(String titulo, boolean tama�o, boolean cerrar, boolean maximizar, MuseoBD padre) {
		super(titulo, tama�o, cerrar, maximizar);
		getContentPane().setBackground(Color.DARK_GRAY);
		setVisible(true);
		principal = padre;
		contentPanel = (JPanel) this.getContentPane();
		contentPanel.setLayout(null);
		
		JLabel lblEstatua = new JLabel("Estatua");
		lblEstatua.setForeground(Color.CYAN);
		lblEstatua.setFont(new Font("Source Code Pro", Font.BOLD | Font.ITALIC, 62));
		lblEstatua.setBounds(32, 13, 294, 66);
		getContentPane().add(lblEstatua);
		
		JLabel lblIdobjeto = new JLabel("IdObjeto");
		lblIdobjeto.setForeground(Color.WHITE);
		lblIdobjeto.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblIdobjeto.setBounds(12, 92, 139, 46);
		getContentPane().add(lblIdobjeto);
		
		JLabel lblMaterial = new JLabel("Material");
		lblMaterial.setForeground(Color.WHITE);
		lblMaterial.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblMaterial.setBounds(12, 151, 139, 46);
		getContentPane().add(lblMaterial);
		
		txtIdObje = new JTextField();
		txtIdObje.setColumns(10);
		txtIdObje.setBounds(145, 111, 164, 22);
		getContentPane().add(txtIdObje);
		
		txtMaterial = new JTextField();
		txtMaterial.setColumns(10);
		txtMaterial.setBounds(145, 170, 164, 22);
		getContentPane().add(txtMaterial);
		
		JButton btnAlta = new JButton("Alta");
		btnAlta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CallableStatement cs = null;
				//idObje,material
				try {
					Connection con = Conexion.getConection();
					cs = con.prepareCall("{call InsertEstatua(?,?)}");
					cs.setString("idObje",txtIdObje.getText());
					cs.setString("material",txtMaterial.getText());
					
					cs.execute();
					JOptionPane.showMessageDialog(null, "Estatua de Arte Ingresado");
					txtIdObje.setText("");
					txtMaterial.setText("");
				} catch (SQLException e2) {
					e2.printStackTrace();
				}
			}
		});
		btnAlta.setBounds(103, 210, 97, 25);
		getContentPane().add(btnAlta);
		
		JButton btnBaja = new JButton("Baja");
		btnBaja.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CallableStatement cs = null;
				try {
					Connection con = Conexion.getConection();
					cs = con.prepareCall("delete from estatua where idObje=?");
					cs.setString(1, txtIdObje.getText());
					
					cs.execute();
					JOptionPane.showMessageDialog(null, "Estatua Borrado Corectamente");
					txtIdObje.setText("");
					txtMaterial.setText("");
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		});
		btnBaja.setBounds(212, 210, 97, 25);
		getContentPane().add(btnBaja);

		setBounds(100, 100, 354, 292);

	}
}
