package BaseDatos;
import java.awt.Color;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
public class ObjArte_Exhib extends JInternalFrame{
	public MuseoBD principal;
	public JPanel contentPanel;
	private JTextField txtIdObje;
	private JTextField txtIdExh;

	public ObjArte_Exhib(String titulo, boolean tama�o, boolean cerrar, boolean maximizar, MuseoBD padre) {
		super(titulo, tama�o, cerrar, maximizar);
		getContentPane().setBackground(Color.DARK_GRAY);
		setVisible(true);
		principal = padre;
		contentPanel = (JPanel) this.getContentPane();
		contentPanel.setLayout(null);
		
		JLabel lblObjetoDeArte = new JLabel("Objeto de Arte y");
		lblObjetoDeArte.setForeground(Color.WHITE);
		lblObjetoDeArte.setFont(new Font("Source Code Pro", Font.BOLD | Font.ITALIC, 62));
		lblObjetoDeArte.setBounds(0, 13, 646, 66);
		getContentPane().add(lblObjetoDeArte);
		
		JLabel lblExhibicion = new JLabel("Exhibicion");
		lblExhibicion.setForeground(Color.CYAN);
		lblExhibicion.setFont(new Font("Source Code Pro", Font.BOLD | Font.ITALIC, 62));
		lblExhibicion.setBounds(105, 79, 400, 66);
		getContentPane().add(lblExhibicion);
		
		JLabel lblIdObjeto = new JLabel("Id Objeto");
		lblIdObjeto.setForeground(Color.WHITE);
		lblIdObjeto.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblIdObjeto.setBounds(12, 157, 149, 52);
		getContentPane().add(lblIdObjeto);
		
		JLabel lblIdExhibicion = new JLabel("id Exhibicion");
		lblIdExhibicion.setForeground(Color.WHITE);
		lblIdExhibicion.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblIdExhibicion.setBounds(0, 200, 167, 52);
		getContentPane().add(lblIdExhibicion);
		
		txtIdObje = new JTextField();
		txtIdObje.setColumns(10);
		txtIdObje.setBounds(179, 179, 164, 22);
		getContentPane().add(txtIdObje);
		
		txtIdExh = new JTextField();
		txtIdExh.setColumns(10);
		txtIdExh.setBounds(179, 222, 164, 22);
		getContentPane().add(txtIdExh);
		
		JButton btnAlta = new JButton("Alta");
		btnAlta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CallableStatement cs = null;
				//Objart_exhib values (idObje,idExb)
				//call InsertObjart_exhib
				try {
					Connection con = Conexion.getConection();
					cs = con.prepareCall("{call InsertExhibicion(?,?)}");
					cs.setString("idObje",txtIdObje.getText());
					cs.setString("idExb",txtIdExh.getText());
					
					cs.execute();
					JOptionPane.showMessageDialog(null, "Objeto de arte y Exhibicion Conectado");
					txtIdExh.setText(null);
					txtIdObje.setText(null);
				} catch (SQLException e2) {
					e2.printStackTrace();
				}
			}
		});
		btnAlta.setBounds(440, 248, 97, 25);
		getContentPane().add(btnAlta);
		
		JButton btnBaja = new JButton("Baja");
		btnBaja.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CallableStatement cs = null;
				try {
					Connection con = Conexion.getConection();
					if(txtIdExh.getText()==null) {
						cs = con.prepareCall("delete from Objart_exhib where idObje=?");
						cs.setString(1, txtIdObje.getText());
					}else {
						cs = con.prepareCall("delete from Objart_exhib where idExb=?");
						cs.setString(1, txtIdExh.getText());
					}
					cs.execute();
					JOptionPane.showMessageDialog(null, "Exhibicion conexion con Objeto de arte Borrado Corectamente");
					
				} catch (SQLException e2) {
					e2.printStackTrace();
				}
				
				
			}
		});
		btnBaja.setBounds(549, 248, 97, 25);
		getContentPane().add(btnBaja);

		setBounds(100, 100, 674, 322);

	}
}
