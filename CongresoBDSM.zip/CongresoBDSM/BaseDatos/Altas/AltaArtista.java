package BaseDatos.Altas;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import BaseDatos.Conexion;
import BaseDatos.MuseoBD;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class AltaArtista extends JInternalFrame {
	public MuseoBD principal;
	public JPanel contentPanel;
	private JTextField txtIdObje;
	private JTextField txtNombre;
	private JTextField txtFechNa;
	private JTextField txtFechaMu;
	private JTextField txtEstilo;
	private JTextField txtEpoca;
	private JTextField txtPais;

	public AltaArtista(String titulo, boolean tama�o, boolean cerrar, boolean maximizar, MuseoBD padre) {
		super(titulo, tama�o, cerrar, maximizar);
		getContentPane().setBackground(Color.DARK_GRAY);
		setVisible(true);
		principal = padre;
		contentPanel = (JPanel) this.getContentPane();
		contentPanel.setLayout(null);

		JLabel lblAltaartista = new JLabel("Artista");
		lblAltaartista.setForeground(Color.CYAN);
		lblAltaartista.setFont(new Font("Source Code Pro", Font.BOLD | Font.ITALIC, 62));
		lblAltaartista.setBounds(12, 13, 463, 66);
		getContentPane().add(lblAltaartista);

		JLabel lblIdobje = new JLabel("idObje");
		lblIdobje.setForeground(Color.WHITE);
		lblIdobje.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblIdobje.setBounds(12, 92, 118, 43);
		getContentPane().add(lblIdobje);

		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setForeground(Color.WHITE);
		lblNombre.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNombre.setBounds(275, 92, 134, 43);
		getContentPane().add(lblNombre);

		JLabel lblFechaDeNacimiento = new JLabel("Fecha de Nacimiento");
		lblFechaDeNacimiento.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblFechaDeNacimiento.setForeground(Color.WHITE);
		lblFechaDeNacimiento.setBounds(12, 148, 337, 43);
		getContentPane().add(lblFechaDeNacimiento);

		JLabel lblEpoca = new JLabel("Epoca");
		lblEpoca.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblEpoca.setForeground(Color.WHITE);
		lblEpoca.setBounds(275, 245, 97, 43);
		getContentPane().add(lblEpoca);

		JLabel lblFechaDeMuerte = new JLabel("Fecha de Muerte");
		lblFechaDeMuerte.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblFechaDeMuerte.setForeground(Color.WHITE);
		lblFechaDeMuerte.setBounds(12, 189, 257, 43);
		getContentPane().add(lblFechaDeMuerte);

		JLabel lblPais = new JLabel("Pais");
		lblPais.setForeground(Color.WHITE);
		lblPais.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblPais.setBounds(12, 293, 88, 43);
		getContentPane().add(lblPais);

		JLabel lblEstilo = new JLabel("Estilo");
		lblEstilo.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblEstilo.setForeground(Color.WHITE);
		lblEstilo.setBounds(12, 245, 118, 43);
		getContentPane().add(lblEstilo);

		txtIdObje = new JTextField();
		txtIdObje.setColumns(10);
		txtIdObje.setBounds(105, 109, 164, 22);
		getContentPane().add(txtIdObje);

		txtNombre = new JTextField();
		txtNombre.setColumns(10);
		txtNombre.setBounds(394, 109, 164, 22);
		getContentPane().add(txtNombre);

		txtFechNa = new JTextField();
		txtFechNa.setColumns(10);
		txtFechNa.setBounds(301, 165, 164, 22);
		getContentPane().add(txtFechNa);

		txtFechaMu = new JTextField();
		txtFechaMu.setColumns(10);
		txtFechaMu.setBounds(301, 206, 164, 22);
		getContentPane().add(txtFechaMu);

		txtEstilo = new JTextField();
		txtEstilo.setColumns(10);
		txtEstilo.setBounds(99, 262, 164, 22);
		getContentPane().add(txtEstilo);

		txtEpoca = new JTextField();
		txtEpoca.setColumns(10);
		txtEpoca.setBounds(394, 262, 164, 22);
		getContentPane().add(txtEpoca);

		txtPais = new JTextField();
		txtPais.setColumns(10);
		txtPais.setBounds(99, 310, 164, 22);
		getContentPane().add(txtPais);

		JButton btnBaja = new JButton("Baja");
		btnBaja.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CallableStatement cs = null;
				try {
					Connection con = Conexion.getConection();
					cs = con.prepareCall("delete from artista where idObje=?");
					cs.setString(1, txtIdObje.getText());
					cs.execute();
					
					
					System.out.println("Test");
					JOptionPane.showMessageDialog(null, "Artista Borrado Corectamente");

				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
		});
		btnBaja.setBounds(461, 309, 97, 25);
		getContentPane().add(btnBaja);

		JButton btnAlta = new JButton("Alta");
		btnAlta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CallableStatement cs = null;
				try {
					// IN idObje integer,IN nomArt varchar(30),
					// IN fechaNa date,IN epoca varchar(20),
					// IN fechaDef date,IN pais varchar(20),
					// IN estilo varchar(35)
					Connection con = Conexion.getConection();
					cs = con.prepareCall("{call InsertArtista(?,?,?,?,?,?,?)}");
					
					
					cs.setString("idObje", txtIdObje.getText());
					cs.setString("nomArt", txtNombre.getText());
					cs.setString("fechaNa", txtFechNa.getText());
					cs.setString("epoca", txtEpoca.getText());
					cs.setString("fechaDef", txtFechaMu.getText());
					cs.setString("pais", txtPais.getText());
					cs.setString("estilo", txtEstilo.getText());

					cs.execute();
					JOptionPane.showMessageDialog(null, "Artista Ingresado");
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
		});
		btnAlta.setBounds(352, 309, 97, 25);
		getContentPane().add(btnAlta);

		setBounds(100, 100, 593, 392);

	}
}
