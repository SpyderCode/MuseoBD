package BaseDatos.Altas;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import BaseDatos.Conexion;
import BaseDatos.MuseoBD;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class AltaOtro extends JInternalFrame {
	public MuseoBD principal;
	public JPanel contentPanel;
	private JTextField txtIdObjeto;
	private JTextField txtEstilo;
	private JTextField txtTipo;

	public AltaOtro(String titulo, boolean tama�o, boolean cerrar, boolean maximizar, MuseoBD padre) {
		super(titulo, tama�o, cerrar, maximizar);
		getContentPane().setBackground(Color.DARK_GRAY);
		setVisible(true);
		principal = padre;
		contentPanel = (JPanel) this.getContentPane();
		contentPanel.setLayout(null);

		JLabel lblOtro = new JLabel("Otro");
		lblOtro.setBackground(new Color(240, 240, 240));
		lblOtro.setForeground(Color.CYAN);
		lblOtro.setFont(new Font("Source Code Pro Black", Font.BOLD | Font.ITALIC, 62));
		lblOtro.setBounds(79, 13, 164, 66);
		getContentPane().add(lblOtro);

		JLabel lblIdobjeto = new JLabel("IdObjeto");
		lblIdobjeto.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblIdobjeto.setForeground(Color.WHITE);
		lblIdobjeto.setBounds(12, 92, 118, 46);
		getContentPane().add(lblIdobjeto);

		JLabel lblEstilo = new JLabel("Estilo");
		lblEstilo.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblEstilo.setForeground(Color.WHITE);
		lblEstilo.setBounds(12, 132, 118, 46);
		getContentPane().add(lblEstilo);

		JLabel lblTipo = new JLabel("Tipo");
		lblTipo.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblTipo.setForeground(Color.WHITE);
		lblTipo.setBounds(12, 178, 118, 46);
		getContentPane().add(lblTipo);

		txtIdObjeto = new JTextField();
		txtIdObjeto.setColumns(10);
		txtIdObjeto.setBounds(142, 111, 164, 22);
		getContentPane().add(txtIdObjeto);

		txtEstilo = new JTextField();
		txtEstilo.setColumns(10);
		txtEstilo.setBounds(142, 151, 164, 22);
		getContentPane().add(txtEstilo);

		txtTipo = new JTextField();
		txtTipo.setColumns(10);
		txtTipo.setBounds(142, 197, 164, 22);
		getContentPane().add(txtTipo);

		JButton btnAlta = new JButton("Alta");
		btnAlta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CallableStatement cs = null;
				// idObje,estilo,tipo
				// call InsertOtro
				try {
					Connection con = Conexion.getConection();
					cs = con.prepareCall("{call InsertOtro(?,?)}");
					cs.setString("idObje", txtIdObjeto.getText());
					cs.setString("estilo", txtEstilo.getText());
					cs.setString("tipo", txtTipo.getText());

					cs.execute();
					JOptionPane.showMessageDialog(null, "Otro Ingresado");
					clearTxt();

				} catch (SQLException e2) {
					e2.printStackTrace();
				}
			}
		});
		btnAlta.setBounds(100, 237, 97, 25);
		getContentPane().add(btnAlta);

		JButton btnBaja = new JButton("Baja");
		btnBaja.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CallableStatement cs = null;
				try {
					Connection con = Conexion.getConection();
					cs = con.prepareCall("delete from otro where idObje=?");
					cs.setString(1, txtIdObjeto.getText());
					
					cs.execute();
					JOptionPane.showMessageDialog(null, "Estatua Borrado Corectamente");
					clearTxt();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		});
		btnBaja.setBounds(209, 237, 97, 25);
		getContentPane().add(btnBaja);

		setBounds(100, 100, 342, 324);

	}

	protected void clearTxt() {
		txtIdObjeto.setText("");
		txtEstilo.setText("");
		txtTipo.setText("");

	}
}
