package BaseDatos.Ver;

import java.awt.Color;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;
import BaseDatos.Conexion;
import BaseDatos.MuseoBD;
import javax.swing.JTextField;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import javax.swing.BorderFactory;
import javax.swing.border.Border;

public class VerEstatua extends JInternalFrame{
	public MuseoBD principal;
	public JPanel contentPanel;
	Border border = BorderFactory.createLineBorder(Color.BLACK, 1);
	private JTextField txtId;

	public VerEstatua(String titulo, boolean tama�o, boolean cerrar, boolean maximizar, MuseoBD padre) {
		super(titulo, tama�o, cerrar, maximizar);
		getContentPane().setBackground(Color.DARK_GRAY);
		setVisible(true);
		principal = padre;
		contentPanel = (JPanel) this.getContentPane();
		contentPanel.setLayout(null);
		
		JLabel lblEstatuas = new JLabel("Estatuas");
		lblEstatuas.setForeground(Color.CYAN);
		lblEstatuas.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 69));
		lblEstatuas.setBounds(12, 13, 564, 84);
		getContentPane().add(lblEstatuas);
		
		JLabel lblId = new JLabel("ID");
		lblId.setForeground(Color.WHITE);
		lblId.setFont(new Font("Tahoma", Font.PLAIN, 29));
		lblId.setBounds(12, 99, 36, 45);
		getContentPane().add(lblId);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBorder(border);
		scrollPane.setBounds(12, 152, 772, 306);
		getContentPane().add(scrollPane);
		
		txtId = new JTextField();
		txtId.setColumns(10);
		txtId.setBounds(48, 117, 354, 22);
		getContentPane().add(txtId);
		
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.setBounds(414, 116, 97, 25);
		getContentPane().add(btnBuscar);
		
		JButton btnActualizar = new JButton("Actualizar");
		btnActualizar.setBounds(523, 116, 97, 25);
		getContentPane().add(btnActualizar);

		setBounds(100, 100, 807, 503);

	}
}
