package BaseDatos.Ver;

import java.awt.Color;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JCheckBox;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;

import BaseDatos.Conexion;
import BaseDatos.MuseoBD;

import javax.swing.JTextField;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JRadioButton;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class VerObjeto_arte extends JInternalFrame {
	public MuseoBD principal;
	public JPanel contentPanel;
	private JTextField txtBuscar;
	Border border = BorderFactory.createLineBorder(Color.BLACK, 1);
	private JTable table;

	public VerObjeto_arte(String titulo, boolean tama�o, boolean cerrar, boolean maximizar, MuseoBD padre) {
		super(titulo, tama�o, cerrar, maximizar);
		getContentPane().setBackground(Color.DARK_GRAY);
		setVisible(true);
		principal = padre;
		contentPanel = (JPanel) this.getContentPane();
		contentPanel.setLayout(null);

		JLabel lblObjetosDeArte = new JLabel("Objetos de Arte");
		lblObjetosDeArte.setForeground(Color.CYAN);
		lblObjetosDeArte.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 69));
		lblObjetosDeArte.setBounds(12, 0, 564, 84);
		getContentPane().add(lblObjetosDeArte);

		JLabel lblId = new JLabel("ID");
		lblId.setForeground(Color.WHITE);
		lblId.setFont(new Font("Tahoma", Font.PLAIN, 29));
		lblId.setBounds(12, 86, 36, 45);
		getContentPane().add(lblId);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBorder(border);
		scrollPane.setBounds(12, 139, 772, 306);
		getContentPane().add(scrollPane);

		table = new JTable();
		table.setFont(new Font("Tahoma", Font.PLAIN, 18));
		scrollPane.setViewportView(table);

		txtBuscar = new JTextField();
		txtBuscar.setColumns(10);
		txtBuscar.setBounds(48, 104, 354, 22);
		getContentPane().add(txtBuscar);

		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Campo = txtBuscar.getText();
				String where = "";

				if (!"".equals(Campo)) {
					where = "WHERE idObje = '" + Campo + "'";
				}
				try {
					// New Table
					DefaultTableModel modelo = new DefaultTableModel();
					table.setModel(modelo);

					// Para lo de SQL
					PreparedStatement ps = null;
					ResultSet rs = null;
					@SuppressWarnings("unused")
					Conexion conn = new Conexion();
					Connection con = Conexion.getConection();

					String sql = "Select idObje,pais,a�o,titulo,epoca," + "descripcion FROM objeto_arte " + where;
					System.out.println(sql);

					ps = (PreparedStatement) con.prepareStatement(sql);
					rs = ps.executeQuery();

					java.sql.ResultSetMetaData rsMd = rs.getMetaData();
					int cantidadColumnas = rsMd.getColumnCount();

					// Para las columnas
					modelo.addColumn("idObje");
					modelo.addColumn("pais");
					modelo.addColumn("a�o");
					modelo.addColumn("titulo");
					modelo.addColumn("epoca");
					modelo.addColumn("descripcion");

					while (rs.next()) {
						Object[] filas = new Object[cantidadColumnas];
						for (int i = 0; i < cantidadColumnas; i++) {
							filas[i] = rs.getObject(i + 1);
						}
						modelo.addRow(filas);
					}

					
				} catch (SQLException ex) {
					System.err.println(ex.toString());
				}
				
			}
		});
		btnBuscar.setBounds(414, 103, 97, 25);
		getContentPane().add(btnBuscar);

		JButton btnActualizar = new JButton("Actualizar");
		btnActualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String Campo = txtBuscar.getText();
				String where = "";
				try {
					// New Table
					DefaultTableModel modelo = new DefaultTableModel();
					table.setModel(modelo);

					// Para lo de SQL
					PreparedStatement ps = null;
					ResultSet rs = null;
					@SuppressWarnings("unused")
					Conexion conn = new Conexion();
					Connection con = Conexion.getConection();

					String sql = "Select idObje,pais,a�o,titulo,epoca," + "descripcion FROM objeto_arte " + where;
					System.out.println(sql);

					ps = (PreparedStatement) con.prepareStatement(sql);
					rs = ps.executeQuery();

					java.sql.ResultSetMetaData rsMd = rs.getMetaData();
					int cantidadColumnas = rsMd.getColumnCount();

					// Para las columnas
					modelo.addColumn("idObje");
					modelo.addColumn("pais");
					modelo.addColumn("a�o");
					modelo.addColumn("titulo");
					modelo.addColumn("epoca");
					modelo.addColumn("descripcion");

					while (rs.next()) {
						Object[] filas = new Object[cantidadColumnas];
						for (int i = 0; i < cantidadColumnas; i++) {
							filas[i] = rs.getObject(i + 1);
						}
						modelo.addRow(filas);
					}

				} catch (SQLException ex) {
					System.err.println(ex.toString());
				}
			}
		});
		btnActualizar.setBounds(523, 103, 97, 25);
		getContentPane().add(btnActualizar);

		setBounds(100, 100, 812, 494);

	}
}
