create database VentaLibros;
use VentaLibros;

/*Creacion de la DB*/
create table usuarios (
idUsuario integer primary key,
nombre varchar(35),
direccion varchar(35)
);

create table ventas(
idUsuario integer,
idLibro varchar(10),
fecha date,
cantidad integer,
total float
);

create table libros(
idLibro varchar(10) primary key,
titulo varchar(35),
editorial varchar(35),
precio float
);

alter table ventas add foreign key fk_Ventas_Usuarios(idUsuario) references usuarios(idUsuario);
alter table ventas add foreign key fk_Ventas_libros(idLibro) references libros(idLibro);

insert into usuarios values 
(100,"Juan Perez","Canteros 14"),
(101,"Melina Díaz","Soldadores 25"),
(102,"Víctor Juarez","Mecánicos 15");

insert into libros values 
("L1","Taller de Bases de Datos","McGraw-Hill",654.98),
("L2","Fundamentos de Bases de Datos","PrenticeHall", 755.00);

insert into ventas values 
(100,"L1","2012-11-22",1,654.98),
(101,"L2","2012-11-22",2,1510.00);

/*EXAMEN*/
/*a*/
delimiter //
create procedure ventaUsuario(IN id integer) 
begin 
select usuarios.nombre, libros.titulo, ventas.fecha from usuarios, libros,ventas 
where (id=usuarios.idUsuario) AND 
(usuarios.idUsuario=ventas.idUsuario) AND 
(ventas.idLibro = libros.idLibro); 
end; 
//
delimiter ;

/*b*/
delimiter //
create trigger ActualizaVenta 
before update on libros for each row 
begin 
if ((old.precio*1.1) <= NEW.precio) then 
signal sqlstate "45001" set message_text = "Es demasiado lo que subio (solo se permite el 10%)"; 
end if; 
end ; //
delimiter ;

/*Solo es para hacer mas rapido el testeo*/
delimiter //
create procedure updatePrecio(IN porcentaje float, IN id varchar(35)) 
begin 
update libros set precio=(precio+(precio*(porcentaje/100))) where idLibro = (id); 
end; 
//

call updatePrecio(20,"L1");
/*O a la antiguita*/
update libros set precio=(precio*1.2) where idLibro = ("L1");