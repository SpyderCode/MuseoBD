package BaseDatos.Altas;

import java.awt.Color;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import BaseDatos.Conexion;
import BaseDatos.MuseoBD;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class AltaPintura extends JInternalFrame{
	public MuseoBD principal;
	public JPanel contentPanel;
	private JTextField txtidObjeto;
	private JTextField txtTipo;
	private JTextField txtEstilo;
	private JTextField txtMaterial;

	public AltaPintura(String titulo, boolean tama�o, boolean cerrar, boolean maximizar, MuseoBD padre) {
		super(titulo, tama�o, cerrar, maximizar);
		getContentPane().setBackground(Color.DARK_GRAY);
		setVisible(true);
		principal = padre;
		contentPanel = (JPanel) this.getContentPane();
		contentPanel.setLayout(null);
		
		JLabel lblPintura = new JLabel("Pintura");
		lblPintura.setForeground(Color.CYAN);
		lblPintura.setFont(new Font("Source Code Pro", Font.BOLD | Font.ITALIC, 62));
		lblPintura.setBounds(12, 13, 280, 66);
		getContentPane().add(lblPintura);
		
		JLabel lblIdobjeto = new JLabel("idObjeto");
		lblIdobjeto.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblIdobjeto.setForeground(Color.WHITE);
		lblIdobjeto.setBounds(12, 92, 142, 41);
		getContentPane().add(lblIdobjeto);
		
		JLabel lblTipo = new JLabel("tipo");
		lblTipo.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblTipo.setForeground(Color.WHITE);
		lblTipo.setBounds(12, 140, 142, 41);
		getContentPane().add(lblTipo);
		
		JLabel lblEstilo = new JLabel("estilo");
		lblEstilo.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblEstilo.setForeground(Color.WHITE);
		lblEstilo.setBounds(12, 194, 142, 41);
		getContentPane().add(lblEstilo);
		
		JLabel lblMaterial = new JLabel("Material");
		lblMaterial.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblMaterial.setForeground(Color.WHITE);
		lblMaterial.setBounds(12, 248, 142, 46);
		getContentPane().add(lblMaterial);
		
		txtidObjeto = new JTextField();
		txtidObjeto.setColumns(10);
		txtidObjeto.setBounds(128, 108, 164, 22);
		getContentPane().add(txtidObjeto);
		
		txtTipo = new JTextField();
		txtTipo.setColumns(10);
		txtTipo.setBounds(128, 156, 164, 22);
		getContentPane().add(txtTipo);
		
		txtEstilo = new JTextField();
		txtEstilo.setColumns(10);
		txtEstilo.setBounds(128, 210, 164, 22);
		getContentPane().add(txtEstilo);
		
		txtMaterial = new JTextField();
		txtMaterial.setColumns(10);
		txtMaterial.setBounds(128, 267, 164, 22);
		getContentPane().add(txtMaterial);
		
		JButton btnAlta = new JButton("Alta");
		btnAlta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CallableStatement cs = null;
			//call InsertPintura
			//idObje,tipo,estilo,Material
				try {
					 Connection con = Conexion.getConection();
					 cs = con.prepareCall("{call InsertObjetoArte(?,?,?,?)}");
					 cs.setString("idObje",txtidObjeto.getText());
					 cs.setString("tipo",txtTipo.getText());
					 cs.setString("estilo",txtEstilo.getText());
					 cs.setString("Material",txtMaterial.getText());
					 
					 cs.execute();
					 JOptionPane.showMessageDialog(null, "Pintura Ingresado");
					
				} catch (SQLException e2) {
					e2.printStackTrace();
				}
			}
		});
		btnAlta.setBounds(87, 310, 97, 25);
		getContentPane().add(btnAlta);
		
		JButton btnBaja = new JButton("Baja");
		btnBaja.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CallableStatement cs = null;
				try {
					Connection con = Conexion.getConection();
					cs = con.prepareCall("delete from pintura where idObje=?");
					cs.setString(1, txtidObjeto.getText());
					
					cs.execute();
					System.out.println("Test");
					JOptionPane.showMessageDialog(null, "Pintura Borrado Corectamente");
					
				} catch (SQLException e2) {
					e2.printStackTrace();
				}
			}
		});
		btnBaja.setBounds(195, 310, 97, 25);
		getContentPane().add(btnBaja);

		setBounds(100, 100, 332, 384);

	}
}
