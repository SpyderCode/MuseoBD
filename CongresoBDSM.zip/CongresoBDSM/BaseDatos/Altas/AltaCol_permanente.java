package BaseDatos.Altas;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import BaseDatos.Conexion;
import BaseDatos.MuseoBD;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class AltaCol_permanente extends JInternalFrame{
	public MuseoBD principal;
	public JPanel contentPanel;
	private JTextField txtIdObje;
	private JTextField txtCosto;
	private JTextField txtFechaAdq;
	private JTextField txtExhibPerm;

	public AltaCol_permanente(String titulo, boolean tama�o, boolean cerrar, boolean maximizar, MuseoBD padre) {
		super(titulo, tama�o, cerrar, maximizar);
		getContentPane().setBackground(Color.DARK_GRAY);
		setVisible(true);
		principal = padre;
		contentPanel = (JPanel) this.getContentPane();
		contentPanel.setLayout(null);
		
		JLabel lblColeccionPermanente = new JLabel("Coleccion");
		lblColeccionPermanente.setForeground(Color.WHITE);
		lblColeccionPermanente.setFont(new Font("Source Code Pro", Font.BOLD | Font.ITALIC, 62));
		lblColeccionPermanente.setBounds(12, 13, 351, 66);
		getContentPane().add(lblColeccionPermanente);
		
		JLabel lblPermanente = new JLabel("Permanente");
		lblPermanente.setForeground(Color.CYAN);
		lblPermanente.setFont(new Font("Source Code Pro", Font.BOLD | Font.ITALIC, 62));
		lblPermanente.setBounds(45, 70, 397, 66);
		getContentPane().add(lblPermanente);
		
		JLabel lblIdobjeto = new JLabel("idObjeto");
		lblIdobjeto.setForeground(Color.WHITE);
		lblIdobjeto.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblIdobjeto.setBounds(12, 144, 120, 41);
		getContentPane().add(lblIdobjeto);
		
		JLabel lblCosto = new JLabel("costo");
		lblCosto.setForeground(Color.WHITE);
		lblCosto.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblCosto.setBounds(12, 198, 120, 41);
		getContentPane().add(lblCosto);
		
		JLabel lblFechaAdquisicion = new JLabel("fecha Adquisicion");
		lblFechaAdquisicion.setForeground(Color.WHITE);
		lblFechaAdquisicion.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblFechaAdquisicion.setBounds(12, 252, 277, 41);
		getContentPane().add(lblFechaAdquisicion);
		
		JLabel lblExhibi = new JLabel("Exhibicion Permanente");
		lblExhibi.setForeground(Color.WHITE);
		lblExhibi.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblExhibi.setBounds(12, 304, 318, 41);
		getContentPane().add(lblExhibi);
		
		txtIdObje = new JTextField();
		txtIdObje.setColumns(10);
		txtIdObje.setBounds(140, 160, 164, 22);
		getContentPane().add(txtIdObje);
		
		txtCosto = new JTextField();
		txtCosto.setColumns(10);
		txtCosto.setBounds(140, 214, 164, 22);
		getContentPane().add(txtCosto);
		
		txtFechaAdq = new JTextField();
		txtFechaAdq.setColumns(10);
		txtFechaAdq.setBounds(331, 268, 164, 22);
		getContentPane().add(txtFechaAdq);
		
		txtExhibPerm = new JTextField();
		txtExhibPerm.setColumns(10);
		txtExhibPerm.setBounds(331, 320, 164, 22);
		getContentPane().add(txtExhibPerm);
		
		JButton btnAlta = new JButton("Alta");
		btnAlta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CallableStatement cs = null;
				//col_permanente values (idObje,costo,fechaAdq,Exxhib_Perman);
				try {
					Connection con = Conexion.getConection();
					cs = con.prepareCall("{call InsertEstatua(?,?,?,?)}");
					cs.setString("idObje",txtIdObje.getText());
					cs.setString("costo",txtCosto.getText());
					cs.setString("fechaAdq",txtFechaAdq.getText());
					cs.setString("Exxhib_Perman",txtExhibPerm.getText());
					
					cs.execute();
					JOptionPane.showMessageDialog(null, "Estatua de Arte Ingresado");
					clearText();
					
				} catch (SQLException e2) {
					e2.printStackTrace();
				}
			}
		});
		btnAlta.setBounds(295, 369, 97, 25);
		getContentPane().add(btnAlta);
		
		JButton btnBaja = new JButton("Baja");
		btnBaja.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CallableStatement cs = null;
				try {
					Connection con = Conexion.getConection();
					cs = con.prepareCall("delete from col_permanente where idObje=?");
					cs.setString(1, txtIdObje.getText());
					
					cs.execute();
					JOptionPane.showMessageDialog(null, "Estatua Borrado Corectamente");
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		});
		btnBaja.setBounds(404, 369, 97, 25);
		getContentPane().add(btnBaja);

		setBounds(100, 100, 548, 443);

	}

	protected void clearText() {
		txtIdObje.setText("");
		txtCosto.setText("");
		txtFechaAdq.setText("");
		txtExhibPerm .setText("");
	}   
}
