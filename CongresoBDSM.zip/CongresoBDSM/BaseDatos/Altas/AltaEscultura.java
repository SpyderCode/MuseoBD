package BaseDatos.Altas;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import BaseDatos.Conexion;
import BaseDatos.MuseoBD;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class AltaEscultura extends JInternalFrame{
	public MuseoBD principal;
	public JPanel contentPanel;
	private JTextField txtIdObjeto;
	private JTextField txtEstilo;
	private JTextField textAltura;
	private JTextField txtMaterial;
	private JTextField txtPeso;

	public AltaEscultura(String titulo, boolean tama�o, boolean cerrar, boolean maximizar, MuseoBD padre) {
		super(titulo, tama�o, cerrar, maximizar);
		getContentPane().setBackground(Color.DARK_GRAY);
		setVisible(true);
		principal = padre;
		contentPanel = (JPanel) this.getContentPane();
		contentPanel.setLayout(null);
		
		JLabel lblEscultura = new JLabel("Escultura");
		lblEscultura.setForeground(Color.CYAN);
		lblEscultura.setFont(new Font("Source Code Pro", Font.BOLD | Font.ITALIC, 62));
		lblEscultura.setBounds(12, 13, 354, 66);
		getContentPane().add(lblEscultura);
		
		JLabel lblIdobje = new JLabel("idObjeto");
		lblIdobje.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblIdobje.setForeground(Color.WHITE);
		lblIdobje.setBounds(32, 102, 127, 43);
		getContentPane().add(lblIdobje);
		
		JLabel lblEstilo = new JLabel("Estilo");
		lblEstilo.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblEstilo.setForeground(Color.WHITE);
		lblEstilo.setBounds(32, 158, 127, 43);
		getContentPane().add(lblEstilo);
		
		JLabel lblAltura = new JLabel("Altura");
		lblAltura.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblAltura.setForeground(Color.WHITE);
		lblAltura.setBounds(32, 214, 127, 43);
		getContentPane().add(lblAltura);
		
		JLabel lblMaterial = new JLabel("Material");
		lblMaterial.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblMaterial.setForeground(Color.WHITE);
		lblMaterial.setBounds(347, 155, 127, 42);
		getContentPane().add(lblMaterial);
		
		JLabel lblPeso = new JLabel("Peso");
		lblPeso.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblPeso.setForeground(Color.WHITE);
		lblPeso.setBounds(347, 214, 127, 43);
		getContentPane().add(lblPeso);
		
		txtIdObjeto = new JTextField();
		txtIdObjeto.setColumns(10);
		txtIdObjeto.setBounds(171, 119, 164, 22);
		getContentPane().add(txtIdObjeto);
		
		txtEstilo = new JTextField();
		txtEstilo.setColumns(10);
		txtEstilo.setBounds(171, 175, 164, 22);
		getContentPane().add(txtEstilo);
		
		textAltura = new JTextField();
		textAltura.setColumns(10);
		textAltura.setBounds(171, 231, 164, 22);
		getContentPane().add(textAltura);
		
		txtMaterial = new JTextField();
		txtMaterial.setColumns(10);
		txtMaterial.setBounds(486, 172, 164, 22);
		getContentPane().add(txtMaterial);
		
		txtPeso = new JTextField();
		txtPeso.setColumns(10);
		txtPeso.setBounds(486, 231, 164, 22);
		getContentPane().add(txtPeso);
		
		JButton btnAlta = new JButton("Alta");
		btnAlta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CallableStatement cs = null;
				//call InsertEscultura
				//idObje,estilo,altura,material,peso
				try {
					Connection con = Conexion.getConection();
					cs = con.prepareCall("{call InsertEscultura(?,?,?,?,?)}");
					cs.setString("idObje",txtEstilo.getText());
					cs.setString("estilo",txtEstilo.getText());
					cs.setString("altura",textAltura.getText());
					cs.setString("material",txtMaterial.getText());
					cs.setString("peso",txtPeso.getText());
					
					cs.execute();
					JOptionPane.showMessageDialog(null, "Escultura de Arte Ingresado");
				} catch (SQLException e2) {
					e2.printStackTrace();
				}
				
			}
		});
		btnAlta.setBounds(440, 270, 97, 25);
		getContentPane().add(btnAlta);
		
		JButton btnBaja = new JButton("Baja");
		btnBaja.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CallableStatement cs = null;
				try {
					Connection con = Conexion.getConection();
					cs = con.prepareCall("delete from escultura where idObje=?");
					cs.setString(1, txtIdObjeto.getText());
					
					cs.execute();
					JOptionPane.showMessageDialog(null, "Escultura Borrado Corectamente");
				} catch (SQLException e2) {
					e2.printStackTrace();
				}
				
			}
		});
		btnBaja.setBounds(549, 270, 97, 25);
		getContentPane().add(btnBaja);

		setBounds(100, 100, 674, 341);

	}
}
